#NOTES FOR CLUB LEADERS
##(Fruit Machine)

###Introduction:
This is a simple game that has three sprites that change costume. You have to stop them when they’re showing the same picture (like a fruit machine!).

###Skills
This project covers

- Changing costumes
- Running a loop
- Stopping a loop on click

###Resources
This project uses only standard Scratch images found within Scratch.

###Scratch Cards required:
Broadcast

###Basic exercises
Step 1: Create a sprite that changes costumes 

Step 2: Making the picture change

Step 3: Making it stop when we click on it 

Step 4: Creating the other sprites

###Challenges
1. Make the game harder
2. Make the game get harder and easier over time
3. Detect when all the sprites have stopped on the same costume
