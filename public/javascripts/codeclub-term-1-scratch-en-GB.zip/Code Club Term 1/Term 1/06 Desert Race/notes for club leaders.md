#NOTES FOR CLUB LEADERS
##(Desert Race)

##Introduction

This game is a two player game where you race a parrot and a lion across the desert. Each player has to press a key as fast as they can to move their animal, the first one to reach the edge of the screen wins.

##Skills
This project covers: 

* Events
* Variables
* Animation
* Playing Sounds
* Conditional statements 
* Modifying resources

##Resources
This project uses resources found in the scratch backgrounds and costumes folders as well as a user created resource based on a scratch resource.

##Scratch Cards
Say Something

##Basic Exercises

* Step 1: Create the scene and add sprites 
* Step 2: Make the characters move
* Step 3: Starting the race
* Step 4: Finishing the race
* Step 5: Resetting the game 

##Challenge 

Add a booster
