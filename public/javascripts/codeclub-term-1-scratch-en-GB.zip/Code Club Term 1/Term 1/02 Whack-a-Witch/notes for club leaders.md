#NOTES FOR CLUB LEADERS
##(Whack-a-Witch)

###Introduction
This project is like the carnival game called whack-a-mole. You get points for hitting the witches that appear on the screen. The aim is to get as many points as possible in 30 seconds.

###Skills
This project covers:
* Setting a variable
* Loops
* Keeping and setting the score

###Resources
This project uses resources found in the Scratch Backgrounds and Costumes folders

###Scratch Cards required
* Keep score 
* Timer 
* Animate it

###Basic exercises
* Step 1: Create a flying witch
* Step 2: Make the witch appear and vanish randomly 
* Step 3: Make the witch disappear when she’s clicked 
* Step 4: Add a score and timer

###Challenges
1. Add more witches
