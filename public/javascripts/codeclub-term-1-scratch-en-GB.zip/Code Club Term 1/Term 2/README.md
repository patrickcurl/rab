#Hello and welcome to term two of Code Club! 

##New model
Term two uses Scratch again but this time it's much harder. The focus this term is on the students using new found coding skills to create their own projects. 

So for example the first project is a 'Design and animate your own monster project'. We provide the individual parts and some code (on Scratch cards) but it's up to the students to put all this together and be really creative. There is a worksheet for the students follow and notes for you the club leader for each project.

##Timeframes
There are three projects this term and each project should take about 3-4 weeks to complete but you'll need to work at the pace your club goes at. Don't rush them.

__Good luck!__
